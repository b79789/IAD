//
//  GameScene.h
//  CatchEm
//

//  Copyright (c) 2015 Brian Stacks. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface GameScene : SKScene<SKPhysicsContactDelegate>

@end
