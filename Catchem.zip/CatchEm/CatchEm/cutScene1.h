//
//  cutScene1.h
//  CatchEm
//
//  Created by Brian Stacks on 9/10/15.
//  Copyright (c) 2015 Brian Stacks. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface cutScene1 : SKScene

@end
